//
//  DictConv.swift
//  Exam3-20060301Tests
//
//  Created by Digital Media Dept on 2019. 3. 23..
//  Copyright © 2019년 Digital Media Dept. All rights reserved.
//

import Foundation

class DictConv {
    
    class func conversion(given : Dictionary<Int, Array<String>>) -> Dictionary<String, Int> {
        
  
        return returnDictionary
    }
}
