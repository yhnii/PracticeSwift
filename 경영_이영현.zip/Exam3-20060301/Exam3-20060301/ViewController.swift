//
//  ViewController.swift
//  Exam3-20060301
//
//  Created by Digital Media Dept on 2019. 3. 23..
//  Copyright © 2019년 Digital Media Dept. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

